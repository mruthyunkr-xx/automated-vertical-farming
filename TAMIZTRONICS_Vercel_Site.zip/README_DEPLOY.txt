TAMIZTRONICS VERCEL-READY STATIC WEBSITE

This folder has index.html at its root. Upload the entire folder to Vercel Drop,
or copy the files into the root of the connected GitHub repository and redeploy.

Pages:
- index.html: main portfolio and project overview
- project.html: system operation, parts, and budget
- dashboard.html: animated dashboard demo with simulated values and pump toggle
- team.html: team and purpose
- ecard.html: animated flip e-card

Keep pages.css, logo.png, and farm-illustration.png beside the HTML files.
The dashboard readings and pump button are simulated, not connected to hardware.
